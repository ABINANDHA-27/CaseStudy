package CaseStudy;

import java.sql.*;
import java.util.Scanner;

public class StudentManagement {
    private static final Scanner scanner = new Scanner(System.in);

    public static void addStudent() throws Exception {
        System.out.print("Enter student ID: ");
        int studentId = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Enter student name: ");
        String studentName = scanner.nextLine();
        System.out.print("Enter email: ");
        String email = scanner.nextLine();
        System.out.print("Enter major: ");
        String major = scanner.nextLine();
        System.out.print("Enter year: ");
        int year = scanner.nextInt();
        scanner.nextLine();

        String sql = "INSERT INTO Student (student_id, student_name, email, major, year) VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.connect();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, studentId);
            stmt.setString(2, studentName);
            stmt.setString(3, email);
            stmt.setString(4, major);
            stmt.setInt(5, year);
            stmt.executeUpdate();
            System.out.println("Student added successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void viewStudent() throws Exception {
        System.out.print("Enter student ID: ");
        int studentId = scanner.nextInt();
        scanner.nextLine();

        String sql = "SELECT * FROM Student WHERE student_id = ?";

        try (Connection conn = DatabaseConnection.connect();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, studentId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                System.out.println("Student ID: " + rs.getInt("student_id"));
                System.out.println("Student Name: " + rs.getString("student_name"));
                System.out.println("Email: " + rs.getString("email"));
                System.out.println("Major: " + rs.getString("major"));
                System.out.println("Year: " + rs.getInt("year"));
            } else {
                System.out.println("Student not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void updateStudent() throws Exception {
        System.out.print("Enter student ID: ");
        int studentId = scanner.nextInt();
        scanner.nextLine();

        // Fetch current values
        String currentStudentName = null, currentEmail = null, currentMajor = null;
        int currentYear = 0;
        String fetchSql = "SELECT * FROM Student WHERE student_id = ?";
        try (Connection conn = DatabaseConnection.connect();
             PreparedStatement fetchStmt = conn.prepareStatement(fetchSql)) {
            fetchStmt.setInt(1, studentId);
            ResultSet rs = fetchStmt.executeQuery();
            if (rs.next()) {
                currentStudentName = rs.getString("student_name");
                currentEmail = rs.getString("email");
                currentMajor = rs.getString("major");
                currentYear = rs.getInt("year");
            } else {
                System.out.println("Student not found.");
                return;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        System.out.print("Enter new student name or enter old one (" + currentStudentName + "): ");
        String studentName = scanner.nextLine();
        System.out.print("Enter new email or enter old one (" + currentEmail + "): ");
        String email = scanner.nextLine();
        System.out.print("Enter new major  or enter old one (" + currentMajor + "): ");
        String major = scanner.nextLine();
        System.out.print("Enter new year or enter old onet (" + currentYear + "): ");
        String yearInput = scanner.nextLine();
        int year = yearInput.isEmpty() ? currentYear : Integer.parseInt(yearInput);

        String sql = "UPDATE Student SET student_name = ?, email = ?, major = ?, year = ? WHERE student_id = ?";

        try (Connection conn = DatabaseConnection.connect();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, studentName.isEmpty() ? currentStudentName : studentName);
            stmt.setString(2, email.isEmpty() ? currentEmail : email);
            stmt.setString(3, major.isEmpty() ? currentMajor : major);
            stmt.setInt(4, year);
            stmt.setInt(5, studentId);
            int rowsUpdated = stmt.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Student updated successfully.");
            } else {
                System.out.println("Student not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void deleteStudent() throws Exception {
        System.out.print("Enter student ID: ");
        int studentId = scanner.nextInt();
        scanner.nextLine();

        String sql = "DELETE FROM Student WHERE student_id = ?";

        try (Connection conn = DatabaseConnection.connect();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, studentId);
            int rowsDeleted = stmt.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Student deleted successfully.");
            } else {
                System.out.println("Student not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
