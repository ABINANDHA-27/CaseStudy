package CaseStudy;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class CourseManagement {
    private static final Scanner scanner = new Scanner(System.in);

    public static void addCourse() throws Exception {
        System.out.print("Enter course ID: ");
        int courseId = scanner.nextInt();
        scanner.nextLine();  

        System.out.print("Enter course name: ");
        String courseName = scanner.nextLine();
        System.out.print("Enter instructor: ");
        String instructor = scanner.nextLine();
        System.out.print("Enter schedule: ");
        String schedule = scanner.nextLine();
        System.out.print("Enter location: ");
        String location = scanner.nextLine();

        String sql = "INSERT INTO Course (course_id, course_name, instructor, schedule, location) VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.connect();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, courseId);
            stmt.setString(2, courseName);
            stmt.setString(3, instructor);
            stmt.setString(4, schedule);
            stmt.setString(5, location);
            stmt.executeUpdate();
            System.out.println("Course added successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void viewCourse() throws Exception {
        System.out.print("Enter course ID: ");
        int courseId = scanner.nextInt();
        scanner.nextLine(); 

        String sql = "SELECT * FROM Course WHERE course_id = ?";

        try (Connection conn = DatabaseConnection.connect();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, courseId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                System.out.println("Course ID: " + rs.getInt("course_id"));
                System.out.println("Course Name: " + rs.getString("course_name"));
                System.out.println("Instructor: " + rs.getString("instructor"));
                System.out.println("Schedule: " + rs.getString("schedule"));
                System.out.println("Location: " + rs.getString("location"));
            } else {
                System.out.println("Course not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void updateCourse() throws Exception {
        System.out.print("Enter course ID: ");
        int courseId = scanner.nextInt();
        scanner.nextLine(); 

        System.out.print("Enter new course name or enter old one: ");
        String courseName = scanner.nextLine();
        System.out.print("Enter new instructor or enter old one: ");
        String instructor = scanner.nextLine();
        System.out.print("Enter new schedule or enter old one: ");
        String schedule = scanner.nextLine();
        System.out.print("Enter new location or enter old one: ");
        String location = scanner.nextLine();

        String sql = "UPDATE Course SET course_name = ?, instructor = ?, schedule = ?, location = ? WHERE course_id = ?";

        try (Connection conn = DatabaseConnection.connect();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, courseName.isEmpty() ? null : courseName);
            stmt.setString(2, instructor.isEmpty() ? null : instructor);
            stmt.setString(3, schedule.isEmpty() ? null : schedule);
            stmt.setString(4, location.isEmpty() ? null : location);
            stmt.setInt(5, courseId);
            int rowsUpdated = stmt.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Course updated successfully.");
            } else {
                System.out.println("Course not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void deleteCourse() throws Exception {
        System.out.print("Enter course ID: ");
        int courseId = scanner.nextInt();
        scanner.nextLine();  

        String sql = "DELETE FROM Course WHERE course_id = ?";

        try (Connection conn = DatabaseConnection.connect();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, courseId);
            int rowsDeleted = stmt.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Course deleted successfully.");
            } else {
                System.out.println("Course not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
